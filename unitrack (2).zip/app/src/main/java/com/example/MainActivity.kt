package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import com.example.ui.navigation.NavGraph
import com.example.ui.theme.MyApplicationTheme
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    val firebaseApp = try {
      if (FirebaseApp.getApps(this).isNotEmpty()) {
        FirebaseApp.getInstance()
      } else {
        FirebaseApp.initializeApp(this)
      }
    } catch (e: Exception) {
      null
    } ?: try {
      val options = FirebaseOptions.Builder()
        .setApplicationId("1:115194175845:android:e3001fd630aaea7c22418c")
        .setApiKey("AIzaSyDt-52vyEb_Pqh6rwoHcDb2Do86tE-1Zhk")
        .setProjectId("unitrack-ea843")
        .setGcmSenderId("115194175845")
        .setStorageBucket("unitrack-ea843.firebasestorage.app")
        .build()
      FirebaseApp.initializeApp(this, options)
    } catch (e: Exception) {
      if (FirebaseApp.getApps(this).isNotEmpty()) FirebaseApp.getInstance() else null
    }
    
    setContent {
      MyApplicationTheme {
        if (firebaseApp == null) {
          Scaffold { innerPadding ->
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "Firebase is not initialized.\nPlease check your google-services.json file.",
                textAlign = TextAlign.Center
              )
            }
          }
        } else {
          NavGraph()
        }
      }
    }
  }
}
