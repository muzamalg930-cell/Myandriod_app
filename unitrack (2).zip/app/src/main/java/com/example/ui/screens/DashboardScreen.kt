package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PriorityLevel
import com.example.data.Task
import com.example.data.TaskRepository
import com.example.data.TaskStatus
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// Bento Theme Colors
val BentoPrimary = Color(0xFF6750a4)
val BentoOnPrimary = Color(0xFFFFFFFF)
val BentoPrimaryContainer = Color(0xFFeaddff)
val BentoOnPrimaryContainer = Color(0xFF21005d)
val BentoSecondaryContainer = Color(0xFFe8def8)
val BentoOnSecondaryContainer = Color(0xFF1d192b)
val BentoError = Color(0xFFba1a1a)
val BentoErrorContainer = Color(0xFFFFDADA)
val BentoOnErrorContainer = Color(0xFF410002)
val BentoBackground = Color(0xFFfef7ff)
val BentoOnBackground = Color(0xFF1d1b1e)
val BentoSurfaceVariant = Color(0xFFe7e0ec)
val BentoOnSurfaceVariant = Color(0xFF49454f)
val BentoOutline = Color(0xFFcac4d0)
val BentoNavSurface = Color(0xFFF3EDF7)
val BentoFabColor = Color(0xFFD0BCFF)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onNavigateToAdd: () -> Unit,
    onSignOut: () -> Unit
) {
    val repository = remember { TaskRepository() }
    val tasks by repository.getTasksFlow().collectAsState(initial = emptyList())
    val coroutineScope = rememberCoroutineScope()
    
    val pendingTasks = tasks.filter { it.status != TaskStatus.COMPLETED }.sortedBy { it.dueDate }
    val completedTasks = tasks.filter { it.status == TaskStatus.COMPLETED }
    val nextTask = pendingTasks.firstOrNull()
    
    val today = Calendar.getInstance()
    val todayTasksCount = pendingTasks.count {
        val taskDate = Calendar.getInstance().apply { timeInMillis = it.dueDate }
        taskDate.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
        taskDate.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)
    }
    
    val progress = if (tasks.isEmpty()) 0f else completedTasks.size.toFloat() / tasks.size.toFloat()

    Scaffold(
        containerColor = BentoBackground,
        bottomBar = { BentoBottomNav(onSignOut = onSignOut) },
        floatingActionButton = { BentoFab(onClick = onNavigateToAdd) },
        floatingActionButtonPosition = FabPosition.End
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            item {
                BentoHeader()
                Spacer(modifier = Modifier.height(16.dp))
            }
            
            if (nextTask != null) {
                item {
                    PriorityNextCard(nextTask, onNavigateToAdd)
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
            
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TodayTasksCard(todayTasksCount, modifier = Modifier.weight(1f))
                    ProgressCard(progress, modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
            
            item {
                UpcomingListCard(
                    tasks = pendingTasks.drop(if (nextTask != null) 1 else 0),
                    onToggleStatus = { task ->
                        coroutineScope.launch {
                            repository.updateTaskStatus(task.id, TaskStatus.COMPLETED)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun BentoHeader() {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 32.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("GOOD MORNING,", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = BentoOnSurfaceVariant, letterSpacing = 1.sp)
            Text("Student", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = BentoOnBackground)
        }
        Box(
            modifier = Modifier.size(48.dp).background(BentoPrimaryContainer, CircleShape).border(2.dp, BentoPrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("S", color = BentoOnPrimaryContainer, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
    }
}

@Composable
fun PriorityNextCard(task: Task, onNavigateToAdd: () -> Unit) {
    val daysUntil = ((task.dueDate - System.currentTimeMillis()) / (1000 * 60 * 60 * 24)).coerceAtLeast(0)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(BentoPrimary, RoundedCornerShape(28.dp))
            .padding(20.dp)
    ) {
        Text("!", fontSize = 80.sp, fontWeight = FontWeight.Black, color = Color.White.copy(alpha = 0.2f), modifier = Modifier.align(Alignment.TopEnd).offset(x = 10.dp, y = (-20).dp))
        Column {
            Surface(color = BentoPrimaryContainer, shape = RoundedCornerShape(percent = 50)) {
                Text("PRIORITY NEXT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BentoOnPrimaryContainer, letterSpacing = 1.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(task.title, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = Color.White, lineHeight = 28.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("Submission due in $daysUntil days", fontSize = 14.sp, color = BentoPrimaryContainer, modifier = Modifier.padding(top = 4.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                Row(horizontalArrangement = Arrangement.spacedBy((-8).dp)) {
                    Box(modifier = Modifier.size(32.dp).background(Color(0xFFd0bcff), CircleShape).border(2.dp, BentoPrimary, CircleShape), contentAlignment = Alignment.Center) {
                        Text(task.subjectId.take(2).uppercase().ifEmpty { "SB" }, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BentoOnPrimaryContainer)
                    }
                    Box(modifier = Modifier.size(32.dp).background(Color(0xFFb69df8), CircleShape).border(2.dp, BentoPrimary, CircleShape), contentAlignment = Alignment.Center) {
                        Text(task.taskType.name.take(2).uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BentoOnPrimaryContainer)
                    }
                }
                Surface(color = BentoPrimaryContainer, shape = RoundedCornerShape(12.dp), onClick = { /* Future details */ }) {
                    Text("Details", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BentoOnPrimaryContainer, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                }
            }
        }
    }
}

@Composable
fun TodayTasksCard(count: Int, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(BentoPrimaryContainer, RoundedCornerShape(24.dp))
            .padding(16.dp)
            .height(100.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(count.toString().padStart(2, '0'), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = BentoOnPrimaryContainer, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
        Text("TODAY'S TASKS", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = BentoOnSurfaceVariant, letterSpacing = 1.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun ProgressCard(progress: Float, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .border(1.dp, BentoOutline, RoundedCornerShape(24.dp))
            .background(BentoNavSurface, RoundedCornerShape(24.dp))
            .padding(16.dp)
            .height(100.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Text("PROGRESS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BentoOnBackground)
            Text("${(progress * 100).toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BentoPrimary)
        }
        Box(modifier = Modifier.fillMaxWidth().height(8.dp).background(BentoSurfaceVariant, CircleShape)) {
            Box(modifier = Modifier.fillMaxWidth(progress).fillMaxHeight().background(BentoPrimary, CircleShape))
        }
        Text("Overall completion", fontSize = 10.sp, color = BentoOnSurfaceVariant)
    }
}

@Composable
fun UpcomingListCard(tasks: List<Task>, onToggleStatus: (Task) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(2.dp, BentoSurfaceVariant, RoundedCornerShape(28.dp))
            .background(BentoBackground, RoundedCornerShape(28.dp))
            .padding(20.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Upcoming", fontWeight = FontWeight.Bold, color = BentoOnBackground)
            Text("See all", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BentoPrimary)
        }
        Spacer(modifier = Modifier.height(16.dp))
        if (tasks.isEmpty()) {
            Text("No upcoming tasks.", fontSize = 14.sp, color = BentoOnSurfaceVariant)
        } else {
            val displayTasks = tasks.take(4)
            displayTasks.forEach { task ->
                BentoTaskItem(task, onToggleStatus)
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun BentoTaskItem(task: Task, onToggleStatus: (Task) -> Unit) {
    val isUrgent = task.priority == PriorityLevel.URGENT || task.priority == PriorityLevel.HIGH
    val iconBg = if (isUrgent) BentoErrorContainer else BentoSecondaryContainer
    val iconColor = if (isUrgent) BentoOnErrorContainer else BentoOnSecondaryContainer
    
    val formatter = remember { SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault()) }
    
    Row(modifier = Modifier.fillMaxWidth().clickable { onToggleStatus(task) }, verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(40.dp).background(iconBg, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Text(task.taskType.name.take(2), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = iconColor)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(task.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = BentoOnBackground, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(formatter.format(Date(task.dueDate)), fontSize = 12.sp, color = BentoOnSurfaceVariant)
        }
        if (isUrgent) {
            Box(modifier = Modifier.size(8.dp).background(BentoError, CircleShape))
        } else {
            Box(modifier = Modifier.size(8.dp).border(1.dp, BentoOutline, CircleShape))
        }
    }
}

@Composable
fun BentoBottomNav(onSignOut: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 16.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .background(BentoNavSurface, RoundedCornerShape(32.dp))
                .padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(modifier = Modifier.background(BentoPrimaryContainer, CircleShape).padding(horizontal = 20.dp, vertical = 4.dp)) {
                    Icon(Icons.Default.Home, contentDescription = "Home", tint = BentoOnPrimaryContainer, modifier = Modifier.size(20.dp))
                }
                Text("Home", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BentoOnBackground, modifier = Modifier.padding(top = 2.dp))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.DateRange, contentDescription = "Calendar", tint = BentoOnSurfaceVariant, modifier = Modifier.size(20.dp).padding(bottom = 2.dp))
                Text("Calendar", fontSize = 10.sp, fontWeight = FontWeight.Medium, color = BentoOnSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box {
                    Icon(Icons.Default.Notifications, contentDescription = "Alerts", tint = BentoOnSurfaceVariant, modifier = Modifier.size(20.dp).padding(bottom = 2.dp))
                    Box(modifier = Modifier.size(8.dp).align(Alignment.TopEnd).offset(x = 2.dp, y = (-2).dp).background(BentoError, CircleShape).border(1.dp, BentoNavSurface, CircleShape))
                }
                Text("Alerts", fontSize = 10.sp, fontWeight = FontWeight.Medium, color = BentoOnSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onSignOut() }) {
                Icon(Icons.Default.Person, contentDescription = "Profile", tint = BentoOnSurfaceVariant, modifier = Modifier.size(20.dp).padding(bottom = 2.dp))
                Text("Profile", fontSize = 10.sp, fontWeight = FontWeight.Medium, color = BentoOnSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

@Composable
fun BentoFab(onClick: () -> Unit, modifier: Modifier = Modifier) {
    FloatingActionButton(
        onClick = onClick,
        modifier = modifier.padding(bottom = 32.dp),
        shape = RoundedCornerShape(16.dp),
        containerColor = BentoFabColor,
        contentColor = BentoOnPrimaryContainer,
        elevation = FloatingActionButtonDefaults.elevation(8.dp)
    ) {
        Icon(Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(28.dp))
    }
}
