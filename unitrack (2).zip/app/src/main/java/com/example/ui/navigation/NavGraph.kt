package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.AddTaskScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DashboardScreen
import com.google.firebase.auth.auth
import com.google.firebase.Firebase
import kotlinx.coroutines.flow.MutableStateFlow

object Routes {
    const val AUTH = "auth"
    const val DASHBOARD = "dashboard"
    const val ADD_TASK = "add_task"
}

@Composable
fun NavGraph() {
    val navController = rememberNavController()
    // A simple flow to observe auth changes. In a real app, use a ViewModel.
    val isUserLoggedIn = MutableStateFlow(Firebase.auth.currentUser != null)
    
    LaunchedEffect(Unit) {
        Firebase.auth.addAuthStateListener { auth ->
            isUserLoggedIn.value = auth.currentUser != null
            if (auth.currentUser != null) {
                navController.navigate(Routes.DASHBOARD) {
                    popUpTo(0) { inclusive = true }
                }
            } else {
                navController.navigate(Routes.AUTH) {
                    popUpTo(0) { inclusive = true }
                }
            }
        }
    }

    val loggedIn by isUserLoggedIn.collectAsState()

    NavHost(
        navController = navController,
        startDestination = if (loggedIn) Routes.DASHBOARD else Routes.AUTH
    ) {
        composable(Routes.AUTH) {
            AuthScreen(
                onAuthSuccess = {
                    // Handled by AuthStateListener, but can be a direct navigate
                }
            )
        }
        composable(Routes.DASHBOARD) {
            DashboardScreen(
                onNavigateToAdd = {
                    navController.navigate(Routes.ADD_TASK)
                },
                onSignOut = {
                    Firebase.auth.signOut()
                }
            )
        }
        composable(Routes.ADD_TASK) {
            AddTaskScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
