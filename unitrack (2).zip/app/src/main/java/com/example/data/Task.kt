package com.example.data

import java.util.UUID

data class Task(
    val id: String = UUID.randomUUID().toString(),
    val userId: String = "",
    val subjectId: String = "",
    val title: String = "",
    val description: String = "",
    val taskType: TaskType = TaskType.ASSIGNMENT,
    val priority: PriorityLevel = PriorityLevel.MEDIUM,
    val dueDate: Long = System.currentTimeMillis(),
    val status: TaskStatus = TaskStatus.NOT_STARTED,
    val createdAt: Long = System.currentTimeMillis()
)

enum class TaskType(val displayName: String) {
    ASSIGNMENT("Assignment"),
    QUIZ("Quiz"),
    EXAM("Exam"),
    PRESENTATION("Presentation"),
    PROJECT("Project"),
    HOMEWORK("Homework"),
    OTHER("Other")
}

enum class PriorityLevel(val displayName: String) {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High"),
    URGENT("Urgent")
}

enum class TaskStatus(val displayName: String) {
    NOT_STARTED("Not Started"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed"),
    OVERDUE("Overdue")
}
